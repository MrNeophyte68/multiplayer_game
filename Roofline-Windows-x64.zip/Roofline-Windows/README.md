# Roofline prototype

Indoor infection parkour for up to 8 players. One player hosts the match.

## Test multiplayer by yourself

1. In Godot, open **Debug → Customize Run Instances…**. Enable multiple instances and set the count to **2**. Press **F5** to run the project.
2. In the first window, choose **Killer**. Press **Tab**, select **Direct LAN / IP address**, then **Host**.
3. In the second window, choose **Survivor**. Press **Tab**, select **Direct LAN / IP address**, enter **127.0.0.1**, then **Join**.
4. Switch windows to control each character. Press **Esc** to release the cursor.

The match starts once the two roles are connected. You can test hits and the spark by leaving one player standing while moving the other. Direct LAN testing needs no Steam account. With two copies of the exported application, use the same connection steps.

## Play with your friend through Steam

- You use the macOS ZIP; send your friend the complete Windows ZIP. Extract it before launching. Keep the Windows executable, PCK, DLLs and steam_appid.txt together.
- Both players run Steam, sign into separate accounts, and launch the game. This prototype uses development App ID **480**.
- Choose Killer on the host and Survivor on the other player. Press Tab to reopen the connection menu.
- Both select **Steam P2P / friends-only lobby**.
- The host clicks **Host**, then **Copy** and sends the lobby code to their friend. The friend pastes it and clicks **Join**. Steam's **Invite Friends** button is another option when the overlay is available.
- Keep the host's game running. There is no host migration.

For two computers on the same home network, you can also use Direct LAN and enter the host's local IP address. The LAN port is UDP 7777. The loopback address 127.0.0.1 works only for two instances on the same computer.

## Controls and settings

- WASD: move; mouse: look; Shift: sprint.
- Space: jump, vault a low obstacle, or kick away from a wall during a wall run.
- Ctrl: crouch; press while sprinting to slide.
- Killer: left mouse button swings the bat. A confirmed hit produces an impact sound and an orange crosshair marker.
- Survivor: G releases a spark. Taking a hit plays a reaction, flashes a subtle red tint and briefly shakes the camera.
- **V: first-person arm settings**. Adjust horizontal position, height, distance and size live. Settings are saved locally; Reset restores defaults.
- Tab: class / connection menu; Esc: release or capture cursor; R: reset only outside a running match.

## Match rules

- A match lasts **12 minutes**. The original Killer starts in the north red bay. Survivors start in the south blue bay.
- A Survivor takes three hits, then respawns after five seconds as a Killer.
- Survivors cannot melee. Each Survivor gets **five spark uses for the entire match**: radius 5.5 metres, six seconds of Killer blindness and stun, eighteen seconds between uses.
- Killers win after every Survivor converts. Survivors win if time runs out while a Survivor remains.
- Roles lock when the match starts. The host can start a new match from Tab; charges reset for that new match.

## Build notes

These builds include the supplied male_casual Survivor, StrawMaw Killer and bat, retargeted Pinoc movement and action animations, a custom slide, and the previous attack animation requested by the user. The map has sixteen symmetric rooms plus corridors and two spawn bays.

Godot 4.7.2 / GodotSteam 4.24. The macOS build is universal (including Apple Silicon); Windows is x64. Steam 480 is for development testing. Publishing the game later requires the project's own Steam App ID and release setup.

Local gameplay checks and a two-process ENet test were run. A live Steam session between separate Mac and Windows Steam accounts still needs a friend test; Windows was cross-exported on macOS.

Motion provenance: Pinoc library and custom motion sources are stored in the editor project's assets/pinoc folder. The retained attack uses Quaternius Universal Animation Library (CC0); its license is included in the editor project.
